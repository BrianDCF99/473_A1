import subprocess
import time
import os

ICGREP = "../build/bin/icgrep"
GREP = "grep"
RGGREP = "rg"
OUTPUT = "results.txt"

REGEX = [
  ("LIT", "Lorem"),
  ("UNI", r"\p{Greek}"),
  ("ALT", "Lorem|ipsum|dolor"),
  ("AMB", "(t|tt)+"),
]
INPUT = [
  "text1.txt",
  "text2.txt",
  "text3.txt",
  "text4.txt",
  "text5.txt",
  "text6.txt",
]
FLAGS = ["", "-i"]
ACTIONS = "instructions,cycles,branch-misses"

# Command invocation ALL
def runThing(cmd):
  start = time.time()
  try:
    result = subprocess.run(
      cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60
    )
    end = time.time()
    return result.stdout, result.stderr, end - start
  except subprocess.TimeoutExpired:
    return b"", b"Timed Out", -1

# Deprecated perfstats helper since it's not supported by rip/grep
def getNumbers(cmd):
  thing_cmd = f"perf stat -x, -e {ACTIONS} {cmd}"
  _, errors, runtime = runThing(thing_cmd) # Command invocation ALL
  instructions = cycles = misses = "(X)"
  for currentLine in errors.decode().splitlines():
    currentLine_segments = currentLine.split(",")
    if len(currentLine_segments) > 2:
      if "instructions" in currentLine:
        instructions = currentLine_segments[0]
      elif "cycles" in currentLine:
        cycles = currentLine_segments[0]
      elif "branch-misses" in currentLine:
        misses = currentLine_segments[0]
  return runtime, instructions, cycles, misses

def isCorrect(pattern, file, flags):
  ic = f"{ICGREP} {flags} '{pattern}' {file}"
  grep = f"{GREP} {flags} '{pattern}' {file}"
  rg = f"{RGGREP} {flags} '{pattern}' {file}"
  icOUTPUT, _, _ = runThing(ic)
  grepOUTPUT, _, _ = runThing(grep)
  rgOUTPUT, _, _ = runThing(rg)
  return (icOUTPUT == grepOUTPUT), (icOUTPUT == rgOUTPUT)

def main():
  with open(OUTPUT, "w") as f:
    f.write("_?_grep | type | pattern | file | flags | time | icgrepXgrep | icgrepXripgrep\n")
    for type, pattern in REGEX:
      for file in INPUT:
        for flag in FLAGS:
          print(f"!!! {pattern} on {file} [{flag}]")
          grepPass, ripgrepPass = isCorrect(pattern, file, flag)

          if not ripgrepPass:
            f.write(f"icgrep != ripgrep | {type} | {pattern} | {file}\n")
            continue
          if not grepPass:
            f.write(f"grep couldn't do it! | {type} | {pattern} | {file}\n")

          ic = f"{ICGREP} {flag} '{pattern}' {file} > /dev/null"
          #t, action, cycle, miss = getNumbers(ic)
          _, _, t = runThing(ic)
          f.write(f"icgrep | {type} | {pattern} | {file} | {flag} | {t:.4f} | {grepPass} | {ripgrepPass}\n")

          grep = f"{GREP} {flag} '{pattern}' {file} > /dev/null"
          #t, action, cycle, miss = getNumbers(grep)
          _, _, t = runThing(grep)
          f.write(f"grep | {type} | {pattern} | {file} | {flag} | {t:.4f} | {grepPass} | {ripgrepPass}\n")

          rg = f"{RGGREP} {flag} '{pattern}' {file} > /dev/null"
          #t, action, cycle, miss = getNumbers(rg)
          _, _, t = runThing(rg)
          f.write(f"ripgrep | {type} | {pattern} | {file} | {flag} | {t:.4f} | {grepPass} | {ripgrepPass}\n")

print(f"\nComplete. See outputs at: {OUTPUT}")

if __name__ == "__main__":
  main()
